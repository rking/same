same: a tool to find duplicate lines of code
============================================

This software is open source, under the GNU Public License.

For licensing info, see GPL.txt.
For installation info, see INSTALL.txt.
For usage info, execute 'same' without command line arguments.
For change info, see ChangeLog.
For future features, see TODO.txt.

Thanks to Baan for giving me the opportunity to write
this software, and to make it open source.

All feedback is welcome at marnix@users.sourceforge.net.

Groetjes,
 <><
Marnix
--
Marnix Klooster
marnix@users.sourceforge.net