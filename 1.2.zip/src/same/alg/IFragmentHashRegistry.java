package same.alg;

public interface IFragmentHashRegistry
{
    void registerFragment(long a_hash, String a_fileName, int a_lineNumber);
}
