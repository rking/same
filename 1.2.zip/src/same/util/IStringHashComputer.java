package same.util;

public interface IStringHashComputer
{
    public long computeStringHash(String a_string);
}
