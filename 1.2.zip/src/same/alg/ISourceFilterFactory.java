package same.alg;

public interface ISourceFilterFactory
{
    ISourceFilter createFilter(String a_fileType);
}
